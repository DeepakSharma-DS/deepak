﻿using StudentInformationFrontEnd.Models.Dto;

namespace StudentInformationFrontEnd.Services
{
    public interface IStudentServices: IBaseServices
    {
        Task<T> GetAllStudentAsync<T>();

        Task<T> GetStudentByIdAsync<T>(int IdStudent);
        Task<T> CreateStudentAsync<T>(StudentDto StudentDto);
        Task<T> UpdateStudentAsync<T>(StudentDto StudentDto);
        Task<T> DeleteStudentAsync<T>(int id);
    
    }
}
