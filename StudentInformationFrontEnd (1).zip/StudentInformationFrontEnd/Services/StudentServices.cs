﻿using StudentInformationFrontEnd.Models.Dto;

namespace StudentInformationFrontEnd.Services
{
    public class StudentServices : BaseServices, IStudentServices
    {
        private readonly IHttpClientFactory _ClientFactory;
        public StudentServices(IHttpClientFactory ClientFactory) : base(ClientFactory)
        {
            _ClientFactory = ClientFactory;

        }

        public async Task<T> CreateStudentAsync<T>(StudentDto StudentDto)
        {
            return await this.SendAsync<T>(

        new ApiRequest()
        {
            ApiType = SD.ApiType.POST,
            Data = StudentDto,
            Url = SD.StudentAPIBase + "api/students/InsertList",
            //  https://localhost:7068/api/students/InsertList

            AccessToken = ""
        }
    );
        }

        public async Task<T> DeleteStudentAsync<T>(int id)
        {
            return await this.SendAsync<T>(

   new ApiRequest()
   {
       ApiType = SD.ApiType.DELETE,

       Url = SD.StudentAPIBase + "api/students/DeleteStudent?IdStudent=" + id,

       AccessToken = ""
   }
);
        }


        public async Task<T> GetAllStudentAsync<T>()
        {
            return await this.SendAsync<T>(

      new ApiRequest()
      {
          ApiType = SD.ApiType.GET,

          Url = SD.StudentAPIBase + "api/students/GetStudentList",

          AccessToken = ""
      }
  );
        }



        public async Task<T> GetStudentByIdAsync<T>(int IdStudent)
        {
            return await this.SendAsync<T>(

     new ApiRequest()
     {
         ApiType = SD.ApiType.GET,

         Url = SD.StudentAPIBase + "api/students/GetStudentById/" + IdStudent,

         AccessToken = ""
     }
);
        }



        public async Task<T> UpdateStudentAsync<T>(StudentDto StudentDto)
        {
            return await this.SendAsync<T>(

       new ApiRequest()
       {
           ApiType = SD.ApiType.PUT,
           Data = StudentDto,
           Url = SD.StudentAPIBase + "api/students/UpdateStudent",

           AccessToken = ""
       }
   );
        }
    }
}
