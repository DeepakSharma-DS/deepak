﻿using StudentInformationFrontEnd.Models.Dto;

namespace StudentInformationFrontEnd.Services
{
    public interface IBaseServices: IDisposable
    {
        ResponseDto responseModel { get; set; }
        Task<T> SendAsync<T>(ApiRequest apiRequest);
    
    }
}
