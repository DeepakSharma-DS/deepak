﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentInformationFrontEnd.Models.Dto;
using StudentInformationFrontEnd.Services;

namespace StudentInformationFrontEnd.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentServices _StudentServices;

        public StudentController(IStudentServices StudentServices)
        {
            _StudentServices = StudentServices;

        }

        public async Task<IActionResult> AddStudent()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddStudent(StudentDto model)
        {
            if (ModelState.IsValid)
            {
                var Response = await _StudentServices.CreateStudentAsync<ResponseDto>(model);
                if (Response != null && Response.IsSuccess)
                {
                    return RedirectToAction(nameof(Student));
                }
            }
            return View(model);
        }


        public async Task<IActionResult> Student()
        {
            List<StudentDto> list = new();
            {
                var response = await _StudentServices.GetAllStudentAsync<ResponseDto>();
                if (response != null && response.IsSuccess)
                {
                    list = JsonConvert.DeserializeObject<List<StudentDto>>(Convert.ToString(response.Result));
                }
                return View(list);
            }
        }

        public async Task<IActionResult> StudentEdit(int IdStudent)
        {
            var response = await _StudentServices.GetStudentByIdAsync<ResponseDto>(IdStudent);
            if (response.IsSuccess)
            {
                StudentDto model = JsonConvert.DeserializeObject<StudentDto>(Convert.ToString(response.Result));
                return View(model);
            }
            return NotFound();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> StudentEdit(StudentDto model)
        {
            if (ModelState.IsValid)
            {
                var response = await _StudentServices.UpdateStudentAsync<ResponseDto>(model);
                if (response != null && response.IsSuccess)
                {
                    return RedirectToAction(nameof(Student));
                }
            }
            return View(model);
        }

        public async Task<IActionResult> StudentDelete(int IdStudent)
        {
            var response = await _StudentServices.GetStudentByIdAsync<ResponseDto>(IdStudent);
            if (response.IsSuccess)
            {
                StudentDto model = JsonConvert.DeserializeObject<StudentDto>(Convert.ToString(response.Result));
                return View(model);
            }
            return NotFound();
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> StudentDelete(StudentDto model)
        {
            if (ModelState.IsValid)
            {
                var response = await _StudentServices.DeleteStudentAsync<ResponseDto>(model.IdStudent);
                if (response != null && response.IsSuccess)
                {
                    return RedirectToAction(nameof(Student));
                }
            }
            return View(model);
        }


    }
}


