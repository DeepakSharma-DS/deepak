﻿namespace StudentInformationFrontEnd
{
    public class SD
    {
        public static string StudentAPIBase { get; set; }

        public enum ApiType
        {
            GET, POST, PUT, DELETE
        }
    }
}
