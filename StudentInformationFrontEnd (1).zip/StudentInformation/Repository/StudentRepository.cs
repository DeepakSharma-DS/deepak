﻿using AutoMapper;
using StudentInformation.DbContexts;
using StudentInformation.Models.Dto;
using StudentInformation.Models;
using StudentInformation.Repository;

namespace StudentInformation.Repository;

public class StudentRepository : IStudentRepository
{
    private readonly ApplicationDbContext _dbContexts;
    private IMapper _Mapper;

    public StudentRepository(ApplicationDbContext dbContexts, IMapper Mapper)
    {
        _dbContexts = dbContexts;
        _Mapper = Mapper;
    }


    public async Task<StudentDto> CreateUpdateStudent(StudentDto StudentDto)
    {
        var Student = _Mapper.Map<StudentDto, Student>(StudentDto);
        if (Student.IdStudent == 0)
        {
            _dbContexts.Student.Add(Student);
        }
        else
        {
            _dbContexts.Student.Update(Student);
        }
        await _dbContexts.SaveChangesAsync();
        return _Mapper.Map<Student, StudentDto>(Student);
    }

    public async Task<StudentDto> Delete(int IdStudent)
    {
        var result = _dbContexts.Student.FirstOrDefault(e => e.IdStudent == IdStudent);
        if (result != null)
        {
            _dbContexts.Student.Remove(result);
            await _dbContexts.SaveChangesAsync();
            return _Mapper.Map<Student, StudentDto>(result);
        }
        return null;
    }

    public async Task<IEnumerable<StudentDto>> GetStudentList()
    {
        var StudentList = _dbContexts.Student.ToList();
        return _Mapper.Map<List<StudentDto>>(StudentList);
    }

    public async Task<StudentDto> GetStudentById(int IdStudent)
    {
        var Student = _dbContexts.Student.Where(u => u.IdStudent == IdStudent).FirstOrDefault();
        return _Mapper.Map<StudentDto>(Student);
    }

    public async Task<StudentDto> InsertUpdate(StudentDto StudentDto)
    {
        var studentDetail = _Mapper.Map<StudentDto, Student>(StudentDto);
        if (studentDetail.IdStudent == 0)
        {
            _dbContexts.Student.Add(studentDetail);
        }
        else
            _dbContexts.Student.Update(studentDetail);
        await _dbContexts.SaveChangesAsync();
        return _Mapper.Map<Student, StudentDto>(studentDetail);
    }

    public Task<StudentDto> GetUserById(int IdStudent)
    {
        throw new NotImplementedException();
    }

    public Task<StudentDto> CreateUpdateUser(StudentDto StudentDto)
    {
        throw new NotImplementedException();
    }
}
