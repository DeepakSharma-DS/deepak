﻿using StudentInformation.Models.Dto;

namespace StudentInformation.Repository
{
    public interface IStudentRepository
    {
        Task<IEnumerable<StudentDto>> GetStudentList();
        Task<StudentDto> InsertUpdate(StudentDto StudentDto);
        Task<StudentDto> Delete(int IdStudent);
        Task<StudentDto> GetStudentById(int IdStudent);
        Task<StudentDto> CreateUpdateStudent(StudentDto StudentDto);
    }
}