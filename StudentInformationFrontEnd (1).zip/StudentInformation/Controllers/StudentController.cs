﻿using Microsoft.AspNetCore.Mvc;
using StudentInformation.Models.Dto;
using StudentInformation.Repository;

namespace StudentInformation.Controllers
{
       [Route("api/students")]
        public class StudentController : ControllerBase
        {


            protected ResponseDto _response;
            private IStudentRepository _StudentRepository;

            public StudentController(IStudentRepository StudentRepository)
            {
                _StudentRepository = StudentRepository;
                _response = new ResponseDto();
            }

            [HttpGet]
            [Route("GetStudentList")]
            public async Task<ResponseDto> Get()
            {
                try
                {
                    var StudentList = await _StudentRepository.GetStudentList();

                    _response.Result = StudentList;

                }
                catch (Exception ex)
                {
                    _response.IsSuccess = false;
                    _response.ErrorMessage = new List<string> { ex.ToString() };
                }
                return _response;
            }



            [HttpPost]
            [Route("InsertList")]
            public async Task<ResponseDto> InsertUpdate([FromBody] StudentDto StudentDto)
            {
                try
                {
                    var StudentList = await _StudentRepository.InsertUpdate(StudentDto);

                    _response.Result = StudentList;

                }
                catch (Exception ex)
                {
                    _response.IsSuccess = false;
                    _response.ErrorMessage = new List<string> { ex.Message };
                }
                return _response;
            }


            [HttpDelete]
            [Route("DeleteStudent")]
            public async Task<ResponseDto> DeleteStudent(int IdStudent)
            {
                try
                {
                    var DeleteStudent = await _StudentRepository.Delete(IdStudent);
                    _response.Result = DeleteStudent;
                }
                catch (Exception ex)
                {
                    _response.IsSuccess = false;
                    _response.ErrorMessage = new List<string> { ex.ToString() };
                }
                return _response;

            }

            [HttpGet]
            [Route("GetStudentById/{Id}")]

            public async Task<ResponseDto> Get(int Id)
            {
                try
                {
                    var StudentDto = await _StudentRepository.GetStudentById(Id);

                    _response.Result = StudentDto;

                }
                catch (Exception ex)
                {
                    _response.IsSuccess = false;
                    _response.ErrorMessage = new List<string>() { ex.ToString() };
                }
                return _response;
            }



            [HttpPut]
            [Route("UpdateStudent")]

            public async Task<object> Put([FromBody] StudentDto StudentDto)
            {
                try
                {
                    var Model = await _StudentRepository.CreateUpdateStudent(StudentDto);
                    _response.Result = Model;
                }
                catch (Exception ex)
                {
                    _response.IsSuccess = false;
                    _response.ErrorMessage = new List<string>() { ex.ToString() };
                }
                return _response;
            }

        }
    }

