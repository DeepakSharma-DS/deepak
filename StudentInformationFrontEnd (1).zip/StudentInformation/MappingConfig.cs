﻿using AutoMapper;
using StudentInformation.Models;
using StudentInformation.Models.Dto;

namespace StudentInformation
{
    public class MappingConfig
    {
        public static MapperConfiguration RegisterMaps()
        {
            var MappingConfig = new MapperConfiguration(config =>
            {
                config.CreateMap<StudentDto, Student>();
                config.CreateMap<Student, StudentDto>();


            });
            return MappingConfig;
        }
    }
}
