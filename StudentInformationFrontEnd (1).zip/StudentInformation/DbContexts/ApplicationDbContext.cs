﻿using Microsoft.EntityFrameworkCore;
using StudentInformation.Models;

namespace StudentInformation.DbContexts
{
    public class ApplicationDbContext:DbContext
    {
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
            {

            }
            public DbSet<Student> Student { get; set; }
        }
    }

