﻿namespace StudentInformation.Models.Dto
{
    public class StudentDto
    {
        public int IdStudent { get; set; }
        public string Name { get; set; }
        public string Class { get; set; }
        public string Section { get; set; }
        public string MobileNo { get; set; }

        public string EmailId { get; set; }
        public string Password { get; set; }
        public string Address { get; set; }
    }
}